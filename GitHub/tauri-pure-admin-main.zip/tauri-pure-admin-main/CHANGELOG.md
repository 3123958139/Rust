# 5.5.0 (2024-05-13)

https://github.com/pure-admin/vue-pure-admin/releases/tag/v5.5.0

# 4.1.0 (2023-05-31)

### 🎫 Feat

- 项目启动和打包添加桌面端和浏览器端区分
- 添加桌面端菜单栏通用配置以及不同平台打包 `icon` 配置
- 使用 `GitHub Actions` 打包出兼容 `macOS`、`Linux` 和 `Windows` 三端的软件安装包，可直接下载安装使用
